/**************************************************************
		Pontificia Universidad Javeriana
	Autor: J. Corredor
	Fecha: Febrero 2024
	Materia: Sistemas Operativos
	Tema: Taller de Evaluaci�n de Rendimiento
	Fichero: fuente de multiplicaci�n de matrices NxN por hilos.
	Objetivo: Evaluar el tiempo de ejecuci�n del 
		     algoritmo cl�sico de multiplicaci�n de matrices.
			     Se implementa con la Biblioteca POSIX Pthreads
****************************************************************/

// Inclusi�n de bibliotecas necesarias
#include <stdio.h>    // Entrada/salida est�ndar (printf)
#include <pthread.h>  // Hilos POSIX (pthread_create, pthread_join, etc.)
#include <unistd.h>   // Funciones del sistema operativo (sleep)
#include <stdlib.h>   // Conversi�n de tipos (atoi), manejo de memoria (malloc)
#include <time.h>     // Funciones de tiempo (time)
#include <sys/time.h> // Mediciones de tiempo precisas (gettimeofday)

// Define el tama�o del bloque de memoria para las matrices
#define DATA_SIZE (1024*1024*64*3) 

// Mutex para controlar el acceso a las matrices (no estrictamente necesario en este caso)
pthread_mutex_t MM_mutex;
// Bloque de memoria para almacenar las matrices
static double MEM_CHUNK[DATA_SIZE];
// Punteros a las matrices
double *mA, *mB, *mC;

// Estructura para pasar par�metros a los hilos
struct parametros{
	int nH;  // N�mero total de hilos
	int idH; // Identificador del hilo
	int N;   // Tama�o de las matrices (N x N)
};

// Variables para medir el tiempo
struct timeval start, stop;

/**
 * Llena las matrices mA y mB con valores y 
 * inicializa la matriz mC con ceros.
 * 
 * @param SZ Tama�o de las matrices (SZ x SZ).
 */
void llenar_matriz(int SZ){ 
	srand48(time(NULL)); // Inicializa el generador de n�meros aleatorios
	for(int i = 0; i < SZ*SZ; i++){
			mA[i] = 1.1*i; //drand48();  // Asigna valores a mA
			mB[i] = 2.2*i; //drand48();  // Asigna valores a mB
			mC[i] = 0;     // Inicializa mC con ceros
		}	
}

/**
 * Imprime una matriz en la pantalla (solo si el tama�o es menor que 12).
 * 
 * @param sz Tama�o de la matriz.
 * @param matriz Puntero a la matriz que se va a imprimir.
 */
void print_matrix(int sz, double *matriz){
	if(sz < 12){
        for(int i = 0; i < sz*sz; i++){
            if(i%sz==0) printf("\n"); // Salto de l�nea al final de cada fila
            printf(" %.3f ", matriz[i]);
		}	
        printf("\n>-------------------->\n");
	}
}

/**
 * Obtiene la marca de tiempo actual al inicio de la ejecuci�n.
 */
void inicial_tiempo(){
	gettimeofday(&start, NULL);
}

/**
 * Obtiene la marca de tiempo actual al final de la ejecuci�n y 
 * calcula e imprime el tiempo transcurrido en microsegundos.
 */
void final_tiempo(){
	gettimeofday(&stop, NULL);
	stop.tv_sec -= start.tv_sec;
	printf("\n:-> %9.0f �s\n", (double) (stop.tv_sec*1000000 + stop.tv_usec));
}

/**
 * Funci�n que ejecuta cada hilo para calcular una parte de la multiplicaci�n de matrices.
 * 
 * @param variables Puntero a la estructura 'parametros' que contiene los datos del hilo.
 * @return NULL
 */
void *mult_thread(void *variables){

	// Convierte el puntero 'void *' a 'struct parametros *'
	struct parametros *data = (struct parametros *)variables; 
	
	int idH = data->idH;  // Obtiene el ID del hilo
	int nH  = data->nH;   // Obtiene el n�mero total de hilos
	int N   = data->N;    // Obtiene el tama�o de la matriz

	// Calcula el rango de filas que este hilo debe procesar
	int ini = (N/nH)*idH;
	int fin = (N/nH)*(idH+1);

    // Bucle para calcular la multiplicaci�n de matrices
    for (int i = ini; i < fin; i++){
        for (int j = 0; j < N; j++){
			double *pA, *pB, sumaTemp = 0.0;
			pA = mA + (i*N);  // Puntero al inicio de la fila i de mA
			pB = mB + j;     // Puntero al inicio de la columna j de mB
            for (int k = 0; k < N; k++, pA++, pB+=N){
				sumaTemp += (*pA * *pB); // Multiplica y acumula
			}
			mC[i*N+j] = sumaTemp; // Guarda el resultado en mC
		}
	}

	// Bloquea y desbloquea el mutex (no es estrictamente necesario en este caso)
	pthread_mutex_lock (&MM_mutex);
	pthread_mutex_unlock (&MM_mutex);

	pthread_exit(NULL); // Termina el hilo
}

/**
 * Funci�n principal del programa.
 * 
 * @param argc N�mero de argumentos de l�nea de comandos.
 * @param argv Arreglo de cadenas con los argumentos de l�nea de comandos.
 * @return 0 si la ejecuci�n es exitosa, -1 si hay un error.
 */
int main(int argc, char *argv[]){
	// Verifica si se proporcionaron suficientes argumentos
	if (argc < 2){
		printf("Ingreso de argumentos \n $./ejecutable tamMatriz numHilos\n");
		return -1;	
	}
    int SZ = atoi(argv[1]);    // Obtiene el tama�o de la matriz de los argumentos
    int n_threads = atoi(argv[2]); // Obtiene el n�mero de hilos de los argumentos

    pthread_t p[n_threads];    // Arreglo de hilos
    pthread_attr_t atrMM;     // Atributos de los hilos

	// Asigna memoria a las matrices dentro del bloque MEM_CHUNK
	mA = MEM_CHUNK;
	mB = mA + SZ*SZ;
	mC = mB + SZ*SZ;

	llenar_matriz(SZ);       // Llena las matrices con valores
	print_matrix(SZ, mA);    // Imprime la matriz mA
	print_matrix(SZ, mB);    // Imprime la matriz mB

	inicial_tiempo();          // Obtiene la marca de tiempo inicial

	pthread_mutex_init(&MM_mutex, NULL);   // Inicializa el mutex
	pthread_attr_init(&atrMM);            // Inicializa los atributos de los hilos
	pthread_attr_setdetachstate(&atrMM, PTHREAD_CREATE_JOINABLE); // Configura los hilos como "joinable"

    // Crea los hilos
    for (int j=0; j<n_threads; j++){
		struct parametros *datos = (struct parametros *) malloc(sizeof(struct parametros)); // Reserva memoria para los par�metros
		datos->idH = j;       // Asigna el ID del hilo
		datos->nH  = n_threads; // Asigna el n�mero total de hilos
		datos->N   = SZ;       // Asigna el tama�o de la matriz
        pthread_create(&p[j],&atrMM,mult_thread,(void *)datos); // Crea el hilo
	}

    // Espera a que todos los hilos terminen
    for (int j=0; j<n_threads; j++)
        pthread_join(p[j],NULL); 

	final_tiempo();        // Obtiene la marca de tiempo final e imprime el tiempo transcurrido
	
	print_matrix(SZ, mC);  // Imprime la matriz resultante mC

	pthread_attr_destroy(&atrMM);   // Destruye los atributos de los hilos
	pthread_mutex_destroy(&MM_mutex);  // Destruye el mutex
	pthread_exit (NULL);          // Termina el programa principal
}