/*********************************************************************
Autor:   Nicolas leon. 
Materia: Sistemas operativos.
Fecha:   25-07-2024.
Tema:    Entrada y Salida en c
**********************************************************************/
include <stidio.h>
include "funciones.h"
int main(int arcg, char *argv[]){
 
  sumarEneteros();
  Calcularareayvolumendcirculos();
  Calcularvoumendcilindr();
  calcuartangente();
  return 0;
}