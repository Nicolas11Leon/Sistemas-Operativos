#include <stdlib.h>
#include <stdio.h>


int main(int argc, char *argv[]){
  int x;
  int suma = 0;
  do{
    scanf("%d", &x);
    suma += x;
    
  }while (x!=0);
  printf ("la suma es %d \n", suma);
  return 0;
}