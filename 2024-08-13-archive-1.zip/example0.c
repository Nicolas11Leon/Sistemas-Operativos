/*********************************************************************
Autor:   Nicolas leon. 
Materia: sistemas operativos.
Fecha:   18-07-2024.
Tema:    Introduccion allenguaje C y los entornos.
         -Entorno en la web(cloud/Nube).
         -Comandos principales de Linux.
         -Programa 1: Bloques basicos de la programacion.
**********************************************************************/

#include <stdio.h>


int main(int arcg, char *argv[]){
  
  printf("\n Hola me llamo Nicolas Leon \n **************** \n Estudio Ingenieria de sistemas y mecatronica, este semestre solo meti media matricula de sistemas \n ~~~~~~~~~~~~~~~ \n estoy viendo: \n Proyecto T.I. \n Sistemas operativos. \n Analisis y Diseño de software. \n Teoria de la computacion, ");
  
  
  
  
  return 0;
}



