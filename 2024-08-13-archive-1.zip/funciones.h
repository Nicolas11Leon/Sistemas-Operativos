/*********************************************************************
Autor:   Nicolas leon. 
Materia: Sistemas operativos.
Fecha:   25-07-2024.
Tema:    Entrada y Salida en c
**********************************************************************/

#include <stdio.h>
float pi=3.141516;

  void sumarEneteros();
  
  void  Calcularareayvolumendcirculos(); 
  
  void Calcularvoumendcilindr();

  void calcuartangente();

  
  
  